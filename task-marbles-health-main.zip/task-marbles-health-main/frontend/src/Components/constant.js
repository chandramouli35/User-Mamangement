module.exports = Object.freeze({
    url: 'https://backend-marbles-health.azurewebsites.net',
});